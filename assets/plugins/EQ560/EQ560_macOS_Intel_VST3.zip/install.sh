#!/bin/bash
echo "Installing EQ560 by c176 Studio (Intel)..."
echo ""

# VST3
echo "Copying VST3..."
sudo rm -rf /Library/Audio/Plug-Ins/VST3/EQ560.vst3
sudo cp -r "$(dirname "$0")/EQ560.vst3" /Library/Audio/Plug-Ins/VST3/
sudo xattr -rd com.apple.quarantine /Library/Audio/Plug-Ins/VST3/EQ560.vst3
sudo codesign --force --deep --sign - /Library/Audio/Plug-Ins/VST3/EQ560.vst3

echo ""
echo "EQ560 (Intel) installed!"
echo "Restart your DAW to scan the new plugin."